package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
	"time"
)

func main() {
	resp, err := http.Get("https://demos.sandbox.tabapay.net/small.txt")
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}

	data := string(body)
	rows := strings.Split(data, "\n")

	// loop thru all logs
	// employee map key: employee ID, value map
	// map key building val room map
	// map key room val map
	// map key in/out val timestamp
	employeeLogs := map[string]map[string]map[string]map[string]string{} // employee -> building -> room -> in/out and time
	for _, row := range rows {
		parts := strings.Split(row, ",")
		// 0 in/out, 1 time, 2 badge, 3 building, 4 room
		if len(parts) < 5 {
			continue
		}
		logType, time, id, building, room := parts[0], parts[1], parts[2], parts[3], parts[4]
		if _, ok := employeeLogs[id]; !ok {
			employeeLogs[id] = map[string]map[string]map[string]string{}
		}
		if _, ok := employeeLogs[id][building]; !ok {
			employeeLogs[id][building] = map[string]map[string]string{}
		}
		if _, ok := employeeLogs[id][building][room]; !ok {
			employeeLogs[id][building][room] = map[string]string{}
		}
		employeeLogs[id][building][room][logType] = time
	}
	// fmt.Println(employeeLogs)

	// Question 1, 2
	for id, buildings := range employeeLogs {
		// fmt.Println(buildings)
		for building, rooms := range buildings {
			t := 0.0
			fmt.Println(id, building)
			for room, log := range rooms {
				if len(log) == 2 {
					t1, _ := convertToTime(log["IN"])
					t2, _ := convertToTime(log["OUT"])
					duration := t2.Sub(t1)
					t += duration.Seconds()
					fmt.Println("\t room", room, duration.Seconds())
				} else {
					fmt.Println("Employee ", id, " Glitched log")
				}
			}
			fmt.Println("\t\t building time", t)
		}
	}

	// Question 3

	// roomLogs := map[string]map[string][]string{} // building-room -> in/out -> timelogs
	// go thru the times
	// room -> employee times
	// [in, in, in]
	// [out, out, out]

	// 	for _, buildings := range employeeLogs {
	// 		for building, rooms := range buildings {
	// 			for room, log := range rooms {
	// 				roomKey := building + "-Room " + room
	// 				if _, ok := roomLogs[roomKey]; !ok {
	// 					roomLogs[roomKey] = map[string][]string{}
	// 				}
	// 				if len(log) == 2 {
	// 					roomLogs[roomKey]["IN"] = append(roomLogs[roomKey]["IN"], log["IN"])
	// 					roomLogs[roomKey]["IN"] = append(roomLogs[roomKey]["OUT"], log["OUT"])
	// 				}
	// 			}
	// 		}
	// 	}

	// 	for room, times := range roomLogs {
	// 		sort.Strings(times["IN"])
	// 		sort.Strings(times["OUT"])
	// 		fmt.Println(times["IN"], times["OUT"])
	// 		mostEmployee := getMostEmployee(times["IN"], times["OUT"])
	// 		fmt.Println(room, mostEmployee)
	// 	}

	// }

	// func getMostEmployee(ins []string, outs []string) int {
	// 	res := 0
	// 	temp := 0
	// 	i, j := 0, 0
	// 	for i < len(ins) {
	// 		temp++
	// 		if temp > res {
	// 			res = temp
	// 		}
	// 		t1, _ := convertToTime(ins[i])
	// 		t2, _ := convertToTime(outs[j])
	// 		for t2.Before(t1) {
	// 			temp--
	// 			j++
	// 			if j == len(outs) {
	// 				break
	// 			}
	// 			t2, _ = convertToTime(outs[j])
	// 		}
	// 		i++
	// 	}
	// 	return res
}

func convertToTime(datetime string) (time.Time, error) {
	layout := "01/02/06 15:04:05"
	parsedTime, err := time.Parse(layout, datetime)
	if err != nil {
		fmt.Println("Error parsing time string:", err)
		return time.Time{}, err
	}

	return parsedTime, nil
}
